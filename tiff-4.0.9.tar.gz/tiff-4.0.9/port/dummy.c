/* $Id: dummy.c,v 1.3 2007/03/21 14:54:16 dron Exp $ */

/*
 * Dummy function, just to be ensure that the library always will be created.
 */

void
libport_dummy_function()
{
        return;
}

