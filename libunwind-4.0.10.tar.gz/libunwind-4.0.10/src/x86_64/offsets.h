/* FreeBSD specific definitions */

#define FREEBSD_UC_MCONTEXT_OFF         0x10
